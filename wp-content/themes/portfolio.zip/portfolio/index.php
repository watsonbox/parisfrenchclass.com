<?php get_header(); ?>
<!-- not used in this template, uses custom page templates, home.php, etc... -->
<?php get_footer(); ?>